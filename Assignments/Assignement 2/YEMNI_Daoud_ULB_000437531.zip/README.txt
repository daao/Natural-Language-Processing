You just need to run the pyton without argument.

If you want to change the input of the parser, you just need to modify or replace the file "input.txt". You just need to respect the format :

*ID* \t *Form* \t *Lemma* \t *POS*

You need also add a blank line between the sentence.